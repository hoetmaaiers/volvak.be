---
title: Hello World
template: project.jade
date: 1988-12-23
---
# World

WorldWorldWorldWorldWorldWorldWorld WorldWorldWorldWorldWorldWorldWorld WorldWorldWorldWorldWorldWorldWorld WorldWorldWorldWorldWorldWorldWorld

![Taketori Monogatari](1.jpeg)
